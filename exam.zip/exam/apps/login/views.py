from __future__ import unicode_literals
from .models import *
from django.shortcuts import render, redirect, HttpResponse
from django.contrib import messages

def index(request):
    print 'index'
    
    return render(request, 'login/index.html')


def register(request):
    print 'register'

    first_name=request.POST['first_name']
    last_name=request.POST['last_name']
    email=request.POST['email']
    password=request.POST['password']
    
    User.objects.create(
        first_name=first_name,
        last_name=last_name,
        email=email, 
        password=password
        )
    
    request.session['email']=request.POST['email']
    
    return redirect('/dashboard')

def login(request):
    print 'login'

    request.session['email']=request.POST['email']
    return redirect('/dashboard')

def dashboard(request):
    print 'dashboard'

    context={
        'items':Item.objects.all(),
        'user':User.objects.get(email=request.session['email'])
    }

    return render(request, 'login/dashboard.html', context)

def create(request):  #CREATE ITEM
    print 'create'

    return render(request, 'login/item.html')

def creation(request):  #CREATE ITEM
    print 'creation'
    print request.POST['item']
    user=User.objects.get(email=request.session['email']).id

    Item.objects.create(name=request.POST['item'], wish_id=user)

    return redirect('/dashboard')

def delete(request):
    print 'create'
    



    return redirect('/dashboard')

